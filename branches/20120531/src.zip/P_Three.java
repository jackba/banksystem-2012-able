import java.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import javax.swing.table.*;
import javax.swing.border.*;
import java.io.*;

class P_Three extends JPanel 
{
	

	JPanel jPanel1;
	JTabbedPane jTabbedPane1;

	public P_Three(Frame f)
	{
		UIManager.put("swing.boldMetal", Boolean.FALSE);

		//setTitle("�� ������");
		setBounds(94, 20, 854, 551);
		//setDefaultCloseOperation(EXIT_ON_CLOSE);

	//	panel = new JPanel();
		setLayout(null);

	
	}

	



	
}
